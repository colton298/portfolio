Known Bug: Sometimes selecting a new weapon will result in another sprite with the same functionality
Music by Micah
All in game art was taken from free sources, with credit: 
Level Design
Spaceship - https://guardian5.itch.io/spaceship-asset 
Mars Background - Matt Cole https://www.vecteezy.com/vector-art/2037399-abstract-background-of-mars-surface 
Neptune Background - Matt Cole  vecteezy.com/vector-art/2097266-abstract-background-of-neptune-surface?autodl_token=fe13ddeab4c9f4be5ffc18c573a2b02693edf1a4754e82afaec142ddb83a03825aeea4d57a030cf833b6794de609b1f6bc054d905cbbbec581ef86d01342f77e 
Payload Sprite - SilverInk https://silverink.itch.io/biped-robot 
Crystal Sprite - CreativeKind https://creativekind.itch.io/gif-bloodmoon-tower-free 
Jungle Level Background - blank canvas https://blank-canvas.itch.io/free-pixel-art-looping-background-jungle 
Jungle Level Trees - https://graphscriptdev.itch.io/plant-trees 
Enemies
Slime - Rvros https://rvros.itch.io/pixel-art-animated-slime 
Skeleton - MonoPixelArt https://monopixelart.itch.io/skeletons-pack 
Golems - MonoPixelArt https://monopixelart.itch.io/golems-pack 
Poison Sap - MonoPixelArt https://monopixelart.itch.io/flying-enemies 
Mushroom - MonoPixelArt https://monopixelart.itch.io/forest-monsters-pixel-art 
Characters
Astronaut - https://floatingkites.itch.io/cute-astronaut 
Ninja - https://cyberrumor.itch.io/16-bit-assassin 
Knight - https://cyberrumor.itch.io/animated-pixel-knight 
Weapons 
Guns - https://ranitaya-studios.itch.io/ranitayas-guns-pack-16-pixelart-guns 
Melee Weapons - https://ranitaya-studios.itch.io/ranitayas-swords-pack 
Sound Effects 
Game Over - https://freesound.org/people/dersuperanton/sounds/434465/
UI - https://jdsherbert.itch.io/pixel-ui-sfx-pack 
Objective SFX - https://www.youtube.com/watch?v=jBsOdep6YqI 
SFX Creator - https://sfxr.me/ 
Space Background - https://www.openaccessgovernment.org/james-webb-space-telescope-unveils-mysteries-of-the-brick/170959/ 
